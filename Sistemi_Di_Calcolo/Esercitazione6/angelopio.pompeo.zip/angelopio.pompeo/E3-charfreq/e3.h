#ifndef __CHF__
#define __CHF__

char charfreq(const char* s);

#endif
