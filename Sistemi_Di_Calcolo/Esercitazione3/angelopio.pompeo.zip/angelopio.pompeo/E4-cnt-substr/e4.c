// Scrivere la soluzione qui

int count_substrings(const char* s, const char* sub){

    int count = 0;

    if(*s == '\0' && *sub == '\0'){
        return 1 ;
    }

    for (int i = 0; s[i] != '\0';i++)
    {
        int k = i;
        for (int j = 0; sub[j] != '\0'; j++)
        {
            if (s[k] != sub[j])
            {
                break;
            }

            k++;
        }
        
        count++;
    }
    return count;
}


