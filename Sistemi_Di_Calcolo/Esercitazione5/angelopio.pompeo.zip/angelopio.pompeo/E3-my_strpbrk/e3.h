#ifndef __MYSRT__
#define __MYSRT__

char *my_strpbrk(const char *s1, const char *s2);

#endif
